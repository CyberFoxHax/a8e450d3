install the level in "marble\data\missions\Multiplayer\custom\MB-Megas\".
if you would like to remix the level, i have provided you the .map file.